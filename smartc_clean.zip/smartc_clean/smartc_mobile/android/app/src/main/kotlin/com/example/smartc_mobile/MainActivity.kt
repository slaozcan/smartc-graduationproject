package com.example.smartc_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
