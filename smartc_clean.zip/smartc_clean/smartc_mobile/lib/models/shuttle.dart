class Shuttle {
  final int id;
  final String name;
  final String route;
  final int capacity;
  final int currentOccupancy;
  final String status;

  Shuttle({
    required this.id,
    required this.name,
    required this.route,
    required this.capacity,
    required this.currentOccupancy,
    required this.status,
  });

  factory Shuttle.fromJson(Map<String, dynamic> json) {
    return Shuttle(
      id: json['id'],
      name: json['name'] ?? '',
      route: json['route'] ?? '',
      capacity: json['capacity'] ?? 50,
      currentOccupancy: json['currentOccupancy'] ?? 0,
      status: json['status'] ?? 'ACTIVE',
    );
  }
}
