class Reservation {
  final int id;
  final int facilityId;
  final String facilityName;
  final String facilityType;
  final DateTime startTime;
  final DateTime endTime;
  final String status;

  Reservation({
    required this.id,
    required this.facilityId,
    required this.facilityName,
    required this.facilityType,
    required this.startTime,
    required this.endTime,
    required this.status,
  });

  factory Reservation.fromJson(Map<String, dynamic> json) {
    return Reservation(
      id: json['id'] ?? 0,
      facilityId: json['facilityId'] ?? 0,
      facilityName: json['facilityName'] ?? '',
      facilityType: json['facilityType'] ?? '',
      startTime: DateTime.parse(json['startTime']),
      endTime: DateTime.parse(json['endTime']),
      status: json['status'] ?? '',
    );
  }
}
