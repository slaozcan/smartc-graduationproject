class Facility {
  final int id;
  final String name;
  final String type;
  final int capacity;
  final double? latitude;
  final double? longitude;

  Facility({
    required this.id,
    required this.name,
    required this.type,
    required this.capacity,
    this.latitude,
    this.longitude,
  });

  factory Facility.fromJson(Map<String, dynamic> json) {
    return Facility(
      id: json['id'],
      name: json['name'] ?? '',
      type: json['type'] ?? 'ROOM',
      capacity: json['capacity'] ?? 1,
      latitude: json['latitude'],
      longitude: json['longitude'],
    );
  }
}
