import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';
import '../models/facility.dart';
import 'package:geolocator/geolocator.dart';

class FacilityScreen extends StatefulWidget {
  const FacilityScreen({Key? key}) : super(key: key);

  @override
  State<FacilityScreen> createState() => _FacilityScreenState();
}

class _FacilityScreenState extends State<FacilityScreen> {
  final ApiService _apiService = ApiService();

  late Future<List<Facility>> _facilitiesFuture;
  String _userRole = "STUDENT";
  Map<int, int> _reservationCounts = {};
  bool _countsLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchFacilities();
    _loadUserRole();
    _loadReservationCounts();
  }

  void _fetchFacilities() {
    setState(() {
      _facilitiesFuture = _apiService.getFacilities();
    });
  }

  Future<void> _loadReservationCounts() async {
    setState(() {
      _countsLoading = true;
    });

    final counts = await _apiService.getActiveReservationCountsByFacility();

    if (!mounted) return;

    setState(() {
      _reservationCounts = counts;
      _countsLoading = false;
    });

    print("RESERVATION COUNTS: $_reservationCounts");
  }

  Future<void> _refreshAll() async {
    _fetchFacilities();
    await _loadReservationCounts();
  }

  Future<void> _loadUserRole() async {
    final prefs = await SharedPreferences.getInstance();
    final role = prefs.getString('userRole') ?? "STUDENT";

    if (!mounted) return;

    setState(() {
      _userRole = role.toUpperCase();
    });
  }

  bool get _isAdmin => _userRole == "ADMIN";

  bool get _canNormalReserve =>
      _userRole != "SHUTTLE_ADMIN" ;

  bool _isExamFacility(Facility facility) {
    final type = facility.type.toUpperCase();
    final name = facility.name.toUpperCase();

    return type.contains("EXAM") ||
        type.contains("CLASSROOM") ||
        name.startsWith("DMF") ||
        name.startsWith("LMF") ||
        name.startsWith("DK") ||
        name.contains("DMF") ||
        name.contains("LMF");
  }

  bool _isFacilityFull(Facility facility) {
    final activeReservations = _reservationCounts[facility.id] ?? 0;
    return activeReservations >= facility.capacity;
  }

  Future<void> _bookFacility(Facility facility) async {
    await _loadReservationCounts();

    if (_isFacilityFull(facility)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Bu tesisin kapasitesi dolmuştur."),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final startTime = DateTime.now();
    final endTime = startTime.add(const Duration(hours: 2));

    LocationPermission permission = await Geolocator.checkPermission();

if (permission == LocationPermission.denied) {
  permission = await Geolocator.requestPermission();
}

if (permission == LocationPermission.denied ||
    permission == LocationPermission.deniedForever) {
  ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(
      content: Text("Konum izni verilmeden rezervasyon yapılamaz."),
      backgroundColor: Colors.red,
    ),
  );
  return;
}

final position = await Geolocator.getCurrentPosition();
print("USER GPS LAT: ${position.latitude}");
print("USER GPS LNG: ${position.longitude}");



final success = await _apiService.createReservation(
  facility.id,
  startTime,
  endTime,
  latitude: position.latitude,
  longitude: position.longitude,
);

    if (!mounted) return;

    await _refreshAll();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          success
              ? 'Rezervasyon başarıyla oluşturuldu!'
              : 'Rezervasyon yapılamadı.',
        ),
        backgroundColor: success ? Colors.green : Colors.red,
      ),
    );
  }

  Future<void> _bookExamFacility(Facility facility) async {
    await _loadReservationCounts();

    if (_isFacilityFull(facility)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Bu sınav odası doludur."),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    if (!_isAdmin || !_isExamFacility(facility)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Sınav rezervasyonu sadece sınav odaları için yapılabilir.',
          ),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final startTime = DateTime.now();
    final endTime = startTime.add(const Duration(hours: 3));

    final success = await _apiService.createExamReservation(
      facility.id,
      startTime,
      endTime,
    );

    if (!mounted) return;

    await _refreshAll();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          success
              ? 'Sınav sınıfı başarıyla rezerve edildi!'
              : 'Sınav sınıfı rezervasyonu başarısız.',
        ),
        backgroundColor: success ? Colors.green : Colors.red,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildHeader(),
        Expanded(
          child: FutureBuilder<List<Facility>>(
            future: _facilitiesFuture,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting ||
                  _countsLoading) {
                return const Center(child: CircularProgressIndicator());
              }

              if (snapshot.hasError) {
                return Center(child: Text("Hata: ${snapshot.error}"));
              }

              if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return const Center(
                  child: Text(
                    "Şu an mevcut tesis bulunmuyor.",
                    style: TextStyle(color: Colors.grey),
                  ),
                );
              }

              final allFacilities = <Facility>[...(snapshot.data ?? [])];

              allFacilities.sort((a, b) => b.id.compareTo(a.id));

              final normalFacilities = allFacilities
                  .where((facility) => !_isExamFacility(facility))
                  .toList();

              final examFacilities = allFacilities
                  .where((facility) => _isExamFacility(facility))
                  .toList();

              return RefreshIndicator(
                onRefresh: _refreshAll,
                child: ListView(
                  padding: const EdgeInsets.all(24),
                  children: [
                    if (_isAdmin) ...[
                      _buildSectionTitle("Normal Odalar"),
                      ...normalFacilities.map<Widget>(
                        (facility) => _buildFacilityCard(
                          facility: facility,
                          showReserveButton: true,
                          showExamButton: false,
                        ),
                      ),
                      const SizedBox(height: 20),
                      _buildSectionTitle("Sınav Odaları"),
                      ...examFacilities.map<Widget>(
                        (facility) => _buildFacilityCard(
                          facility: facility,
                          showReserveButton: false,
                          showExamButton: true,
                        ),
                      ),
                    ] else ...[
                      ...normalFacilities.map<Widget>(
                        (facility) => _buildFacilityCard(
                          facility: facility,
                          showReserveButton: _canNormalReserve,
                          showExamButton: false,
                        ),
                      ),
                    ],
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        color: Color(0xFF1E215D),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(30),
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 24, 24, 40),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "Tesisler / Odalar",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.refresh, color: Colors.white),
                    onPressed: _refreshAll,
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                _isAdmin
                    ? "Admin normal odaları ve sınav odalarını ayrı yönetebilir"
                    : "Rezerve edilebilir uygun alanlar",
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        title,
        style: const TextStyle(
          color: Color(0xFF1E215D),
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }


Widget _buildFacilityCard({
  required Facility facility,
  required bool showReserveButton,
  required bool showExamButton,
}) {
  final activeCount = _reservationCounts[facility.id] ?? 0;
  final isFull = _isFacilityFull(facility);

  return Opacity(
    opacity: isFull ? 0.55 : 1.0,
    child: Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: isFull ? Colors.grey.shade300 : Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isFull ? Colors.grey.shade500 : Colors.transparent,
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (_isAdmin)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(
                "Rol: $_userRole",
                style: const TextStyle(
                  color: Colors.grey,
                  fontSize: 11,
                ),
              ),
            ),

          Text(
            facility.name,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: isFull ? Colors.grey.shade700 : const Color(0xFF1E215D),
            ),
          ),

          const SizedBox(height: 4),

          Text(
            "Tür: ${facility.type} · Kapasite: ${facility.capacity} · Dolu: $activeCount/${facility.capacity}",
            style: TextStyle(
              color: isFull ? Colors.grey.shade700 : Colors.grey,
              fontSize: 13,
            ),
          ),

          const SizedBox(height: 16),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                isFull ? "Tamamen Dolu" : "Müsait",
                style: TextStyle(
                  color: isFull ? Colors.red : Colors.green,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                ),
              ),

              if (!isFull)
                Row(
                  children: [
                    if (showExamButton)
                      ElevatedButton(
                        onPressed: () => _bookExamFacility(facility),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.orange,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Text("Sınav"),
                      ),

                    if (showExamButton && showReserveButton)
                      const SizedBox(width: 8),

                    if (showReserveButton)
                      ElevatedButton(
                        onPressed: _canNormalReserve
                            ? () => _bookFacility(facility)
                            : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF5352ED),
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Text("Rezerve Et"),
                      ),
                  ],
                ),
            ],
          ),
        ],
      ),
    ),
  );
}
}
