import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';
import '../models/announcement.dart';

class AlertsScreen extends StatefulWidget {
  const AlertsScreen({Key? key}) : super(key: key);

  @override
  State<AlertsScreen> createState() => _AlertsScreenState();
}

class _AlertsScreenState extends State<AlertsScreen>
    with SingleTickerProviderStateMixin {
  final ApiService _apiService = ApiService();
  late Future<List<Announcement>> _announcementsFuture;
  late TabController _tabController;

  Set<String> _readAnnouncementIds = {};

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadReadAnnouncements();
    _fetchAnnouncements();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _fetchAnnouncements() {
    setState(() {
      _announcementsFuture = _apiService.getAnnouncements();
    });
  }

  Future<void> _loadReadAnnouncements() async {
    final prefs = await SharedPreferences.getInstance();
    final savedList = prefs.getStringList('read_announcements') ?? [];

    setState(() {
      _readAnnouncementIds = savedList.toSet();
    });
  }

  Future<void> _markAsRead(Announcement ann) async {
    final prefs = await SharedPreferences.getInstance();

    setState(() {
      _readAnnouncementIds.add(ann.id.toString());
    });

    await prefs.setStringList(
      'read_announcements',
      _readAnnouncementIds.toList(),
    );
  }

  bool _isUnread(Announcement ann) {
    return !_readAnnouncementIds.contains(ann.id.toString());
  }

  bool _isShuttleAnnouncement(Announcement ann) {
    final title = ann.title.toLowerCase();
    final content = ann.content.toLowerCase();

    return title.contains("shuttle") ||
        content.contains("shuttle") ||
        title.contains("servis") ||
        content.contains("servis");
  }

  bool _isAnnouncementActive(Announcement ann) {
    final now = DateTime.now();

    // Duyuru oluşturulduktan sonra 7 gün boyunca görünür.
    // 7 gün geçince ekranda gösterilmez.
    final expireDate = ann.createdAt.add(const Duration(days: 30));

    return expireDate.isAfter(now);
  }

  List<Announcement> _getFilteredAnnouncements(
    List<Announcement> announcements,
    bool shuttleOnly,
  ) {
    final filtered = announcements.where((ann) {
      final isActive = _isAnnouncementActive(ann);
      final isShuttle = _isShuttleAnnouncement(ann);

      return isActive && (shuttleOnly ? isShuttle : !isShuttle);
    }).toList();

    filtered.sort((a, b) => b.createdAt.compareTo(a.createdAt));

    return filtered;
  }

  Future<void> _openAnnouncementDetail(Announcement ann) async {
    await _markAsRead(ann);

    if (!mounted) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AnnouncementDetailScreen(
          announcement: ann,
          isShuttle: _isShuttleAnnouncement(ann),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: double.infinity,
          decoration: const BoxDecoration(
            color: Color(0xFF1E215D),
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(30),
            ),
          ),
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        "Duyurular",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.refresh, color: Colors.white),
                        onPressed: _fetchAnnouncements,
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    "Güncel Bildirimler",
                    style: TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                  const SizedBox(height: 20),
                  TabBar(
                    controller: _tabController,
                    indicatorColor: Colors.white,
                    labelColor: Colors.white,
                    unselectedLabelColor: Colors.white70,
                    tabs: const [
                      Tab(text: "Shuttle"),
                      Tab(text: "Diğer"),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        Expanded(
          child: FutureBuilder<List<Announcement>>(
            future: _announcementsFuture,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Center(child: Text("Hata: ${snapshot.error}"));
              } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return const Center(
                  child: Text(
                    "Şu an için yeni bir duyuru yok.",
                    style: TextStyle(color: Colors.grey),
                  ),
                );
              }

              final announcements = List<Announcement>.from(snapshot.data!);

              return TabBarView(
                controller: _tabController,
                children: [
                  _buildAnnouncementList(
                    _getFilteredAnnouncements(announcements, true),
                  ),
                  _buildAnnouncementList(
                    _getFilteredAnnouncements(announcements, false),
                  ),
                ],
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildAnnouncementList(List<Announcement> announcements) {
    if (announcements.isEmpty) {
      return const Center(
        child: Text(
          "Bu kategoride duyuru yok.",
          style: TextStyle(color: Colors.grey),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () async {
        _fetchAnnouncements();
      },
      child: ListView.builder(
        padding: const EdgeInsets.all(24),
        itemCount: announcements.length,
        itemBuilder: (context, index) {
          final ann = announcements[index];

          return Padding(
            padding: const EdgeInsets.only(bottom: 16),
            child: GestureDetector(
              onTap: () => _openAnnouncementDetail(ann),
              child: _buildNotificationCard(
                Icons.campaign,
                Colors.purple,
                ann.title,
                ann.content,
                _formatDate(ann.createdAt),
                _isUnread(ann),
              ),
            ),
          );
        },
      ),
    );
  }

  String _formatDate(DateTime date) {
    return "${date.day}/${date.month}/${date.year} ${date.hour}:${date.minute.toString().padLeft(2, '0')}";
  }

  Widget _buildNotificationCard(
    IconData icon,
    Color color,
    String title,
    String desc,
    String time,
    bool unread,
  ) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        title,
                        style: TextStyle(
                          fontWeight:
                              unread ? FontWeight.bold : FontWeight.w600,
                          fontSize: 15,
                          color: const Color(0xFF1E215D),
                        ),
                      ),
                    ),
                    if (unread)
                      Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                          color: Color(0xFF5352ED),
                          shape: BoxShape.circle,
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  desc,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.grey,
                    fontSize: 13,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  time,
                  style: const TextStyle(
                    color: Colors.grey,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class AnnouncementDetailScreen extends StatelessWidget {
  final Announcement announcement;
  final bool isShuttle;

  const AnnouncementDetailScreen({
    Key? key,
    required this.announcement,
    required this.isShuttle,
  }) : super(key: key);

  String _formatDate(DateTime date) {
    return "${date.day}/${date.month}/${date.year} ${date.hour}:${date.minute.toString().padLeft(2, '0')}";
  }

  @override
  Widget build(BuildContext context) {
    final Color color = isShuttle ? Colors.blue : Colors.purple;
    final String category = isShuttle ? "Shuttle Duyurusu" : "Diğer Duyuru";

    return Scaffold(
      backgroundColor: const Color(0xFFF3F4F8),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E215D),
        elevation: 0,
        title: const Text(
          "Duyuru Detayı",
          style: TextStyle(color: Colors.white),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(22),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  category,
                  style: TextStyle(
                    color: color,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Text(
                announcement.title,
                style: const TextStyle(
                  color: Color(0xFF1E215D),
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                _formatDate(announcement.createdAt),
                style: const TextStyle(
                  color: Colors.grey,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 24),
              Text(
                announcement.content,
                style: const TextStyle(
                  color: Colors.black87,
                  fontSize: 15,
                  height: 1.6,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}