import 'package:flutter/material.dart';

class PrivacyScreen extends StatelessWidget {
  const PrivacyScreen({super.key});

  void _showInfo(BuildContext context, String title, String description) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: Text(description),
        actions: [
  TextButton(
    onPressed: () => Navigator.pop(context),
    child: const Text("Tamam"),
  ),
],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F5FA),
      appBar: AppBar(
        title: const Text("Gizlilik"),
        backgroundColor: const Color(0xFF25255F),
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _PrivacyCard(
            title: "Veri Kullanımı",
            description:
                "SMART-C, kullanıcı deneyimini iyileştirmek için yalnızca gerekli bilgileri kullanır.",
            icon: Icons.storage,
            onTap: () => _showInfo(
              context,
              "Veri Kullanımı",
              "Ad, e-posta, rezervasyon ve uygulama kullanım bilgileri yalnızca SMART-C hizmetlerini sağlamak için kullanılır.",
            ),
          ),
          const SizedBox(height: 16),
          _PrivacyCard(
            title: "Konum İzni",
            description:
                "Rezervasyon işlemlerinde kampüs içi doğrulama için konum bilgisi kullanılabilir.",
            icon: Icons.location_on,
            onTap: () => _showInfo(
              context,
              "Konum İzni",
              "Konum bilgisi; rezervasyon doğrulaması, kampüs içi hizmetler ve shuttle (servis) takibi için uygulama kullanım süresince anlık olarak kullanılabilir.",
            ),
          ),
          const SizedBox(height: 16),
          _PrivacyCard(
            title: "Bildirim İzinleri",
            description:
                "Servis duyuruları, rezervasyon bilgileri ve kampüs bildirimleri için bildirim izni kullanılabilir.",
            icon: Icons.notifications,
            onTap: () => _showInfo(
              context,
              "Bildirim İzinleri",
              "Servis gecikmeleri, iptaller, rezervasyon hatırlatmaları ve kampüs duyuruları için bildirim gönderilebilir.",
            ),
          ),
          const SizedBox(height: 16),
          _PrivacyCard(
            title: "Hesap Güvenliği",
            description:
                "Kullanıcı hesabı JWT tabanlı kimlik doğrulama ile korunur.",
            icon: Icons.security,
            onTap: () => _showInfo(
              context,
              "Hesap Güvenliği",
              "Kullanıcı hesabı JWT tabanlı giriş sistemi ile korunur. Şifre bilgisi güvenlik amacıyla doğrudan gösterilmez.",
            ),
          ),
        ],
      ),
    );
  }
}

class _PrivacyCard extends StatelessWidget {
  final String title;
  final String description;
  final IconData icon;
  final VoidCallback onTap;

  const _PrivacyCard({
    required this.title,
    required this.description,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: const Color(0xFF25255F), size: 30),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF222222),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    description,
                    style: const TextStyle(
                      fontSize: 14,
                      color: Color(0xFF777777),
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(
              Icons.chevron_right,
              color: Color(0xFF25255F),
            ),
          ],
        ),
      ),
    );
  }
}
