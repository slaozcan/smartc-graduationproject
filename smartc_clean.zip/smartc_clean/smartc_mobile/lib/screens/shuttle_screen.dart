import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/api_service.dart';
import '../models/shuttle.dart';

class ShuttleScreen extends StatefulWidget {
  const ShuttleScreen({Key? key}) : super(key: key);

  @override
  State<ShuttleScreen> createState() => _ShuttleScreenState();
}

class _ShuttleScreenState extends State<ShuttleScreen> {
  final ApiService _apiService = ApiService();

  late Future<List<Shuttle>> _shuttlesFuture;

  final Map<int, int> _nearbyUsers = {};

  String _userRole = "STUDENT";

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _routeController = TextEditingController();
  final TextEditingController _capacityController = TextEditingController();
  final TextEditingController _currentOccupancyController =
      TextEditingController();
  final TextEditingController _statusController =
      TextEditingController(text: "ACTIVE");
  final TextEditingController _departureLatitudeController =
      TextEditingController();
  final TextEditingController _departureLongitudeController =
      TextEditingController();

  bool get _isShuttleAdmin => _userRole == "SHUTTLE_ADMIN";

  @override
  void initState() {
    super.initState();
    _loadUserRole();
    _fetchShuttles();
  }

  Future<void> _loadUserRole() async {
    final prefs = await SharedPreferences.getInstance();
    final role = prefs.getString('userRole') ?? "STUDENT";

    if (!mounted) return;

    setState(() {
      _userRole = role.toUpperCase();
    });
  }

  void _fetchShuttles() {
    setState(() {
      _shuttlesFuture = _apiService.getShuttles();
    });

    _shuttlesFuture.then((shuttles) async {
      for (final shuttle in shuttles) {
        final count = await _apiService.getNearbyUsers(shuttle.id);

        if (mounted) {
          setState(() {
            _nearbyUsers[shuttle.id] = count;
          });
        }
      }
    });
  }

  Future<void> _deleteShuttle(int shuttleId) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Shuttle Sil"),
          content: const Text("Bu shuttle silinsin mi?"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text("İptal"),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              onPressed: () => Navigator.pop(context, true),
              child: const Text("Sil"),
            ),
          ],
        );
      },
    );

    if (confirm != true) return;

    try {
      await _apiService.deleteShuttle(shuttleId);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Shuttle başarıyla silindi.")),
      );

      _fetchShuttles();
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Silme hatası: $e")),
      );
    }
  }

  Future<void> _showAddShuttleDialog() async {
    _nameController.clear();
    _routeController.clear();
    _capacityController.clear();
    _currentOccupancyController.text = "0";
    _statusController.text = "ACTIVE";
    _departureLatitudeController.clear();
    _departureLongitudeController.clear();

    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Yeni Shuttle Ekle"),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: _nameController,
                  decoration: const InputDecoration(labelText: "Shuttle Adı"),
                ),
                TextField(
                  controller: _routeController,
                  decoration: const InputDecoration(labelText: "Rota"),
                ),
                TextField(
                  controller: _capacityController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: "Kapasite"),
                ),
                TextField(
                  controller: _currentOccupancyController,
                  keyboardType: TextInputType.number,
                  decoration:
                      const InputDecoration(labelText: "Mevcut Doluluk"),
                ),
                TextField(
                  controller: _statusController,
                  decoration: const InputDecoration(
                    labelText: "Status",
                    hintText: "ACTIVE / DELAYED / FULL",
                  ),
                ),
                TextField(
                  controller: _departureLatitudeController,
                  keyboardType: TextInputType.number,
                  decoration:
                      const InputDecoration(labelText: "Departure Latitude"),
                ),
                TextField(
                  controller: _departureLongitudeController,
                  keyboardType: TextInputType.number,
                  decoration:
                      const InputDecoration(labelText: "Departure Longitude"),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("İptal"),
            ),
            ElevatedButton(
              onPressed: _createShuttle,
              child: const Text("Ekle"),
            ),
          ],
        );
      },
    );
  }

  Future<void> _createShuttle() async {
    if (_nameController.text.trim().isEmpty ||
        _routeController.text.trim().isEmpty ||
        _capacityController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Ad, rota ve kapasite zorunludur.")),
      );
      return;
    }

    final shuttleData = {
      "name": _nameController.text.trim(),
      "route": _routeController.text.trim(),
      "capacity": int.tryParse(_capacityController.text.trim()) ?? 0,
      "currentOccupancy":
          int.tryParse(_currentOccupancyController.text.trim()) ?? 0,
      "status": _statusController.text.trim().isEmpty
          ? "ACTIVE"
          : _statusController.text.trim().toUpperCase(),
      "departureLatitude":
          double.tryParse(_departureLatitudeController.text.trim()),
      "departureLongitude":
          double.tryParse(_departureLongitudeController.text.trim()),
    };

    try {
      await _apiService.createShuttle(shuttleData);

      if (!mounted) return;

      Navigator.pop(context);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Shuttle başarıyla eklendi.")),
      );

      _fetchShuttles();
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Ekleme hatası: $e")),
      );
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _routeController.dispose();
    _capacityController.dispose();
    _currentOccupancyController.dispose();
    _statusController.dispose();
    _departureLatitudeController.dispose();
    _departureLongitudeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: double.infinity,
          decoration: const BoxDecoration(
            color: Color(0xFF1E215D),
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(30),
            ),
          ),
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 40),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        "Shuttle Servisleri",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5,
                        ),
                      ),
                      Row(
                        children: [
                          if (_isShuttleAdmin)
                            IconButton(
                              icon: const Icon(Icons.add_circle,
                                  color: Colors.white),
                              onPressed: _showAddShuttleDialog,
                            ),
                          IconButton(
                            icon:
                                const Icon(Icons.refresh, color: Colors.white),
                            onPressed: _fetchShuttles,
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _isShuttleAdmin
                        ? "Shuttle ekleme ve silme yönetimi"
                        : "Canlı doluluk oranları",
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Expanded(
          child: FutureBuilder<List<Shuttle>>(
            future: _shuttlesFuture,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Center(child: Text("Hata oluştu: ${snapshot.error}"));
              } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return const Center(
                  child: Text(
                    "Şu an aktif bir ring seferi bulunmamaktadır.",
                    style: TextStyle(color: Colors.grey),
                  ),
                );
              }

              final shuttles = snapshot.data!;

              return RefreshIndicator(
                onRefresh: () async {
                  _fetchShuttles();
                },
                child: ListView.builder(
                  padding: const EdgeInsets.all(24),
                  itemCount: shuttles.length,
                  itemBuilder: (context, index) {
                    final shuttle = shuttles[index];

                    final int nearbyCount = _nearbyUsers[shuttle.id] ?? 0;

                    double progress = shuttle.capacity > 0
                        ? (nearbyCount / shuttle.capacity)
                        : 0.0;

                    if (progress > 1.0) progress = 1.0;

                    String percentage = "${(progress * 100).toInt()}%";

                    Color statusColor;
                    Color statusBg;

                    if (shuttle.status == "ACTIVE" ||
                        shuttle.status == "AVAILABLE") {
                      statusColor = Colors.green;
                      statusBg = Colors.green.withOpacity(0.1);
                    } else if (shuttle.status == "DELAYED") {
                      statusColor = Colors.orange;
                      statusBg = Colors.orange.withOpacity(0.1);
                    } else if (progress >= 1.0) {
                      statusColor = Colors.red;
                      statusBg = Colors.red.withOpacity(0.1);
                    } else {
                      statusColor = Colors.indigo;
                      statusBg = Colors.indigo.withOpacity(0.1);
                    }

                    return Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: _buildShuttleCard(
                        shuttleId: shuttle.id,
                        title: shuttle.name.isNotEmpty
                            ? shuttle.name
                            : "Shuttle #${shuttle.id}",
                        status: shuttle.status,
                        statusColor: statusColor,
                        statusBg: statusBg,
                        seats: "$nearbyCount / ${shuttle.capacity} koltuk",
                        percentage: percentage,
                        info:
                            "Rota: ${shuttle.route}\nBekleyen Kullanıcı Sayısı: $nearbyCount",
                        progress: progress,
                        progressColor: statusColor,
                      ),
                    );
                  },
                ),
              );
            },
          ),
        )
      ],
    );
  }

  Widget _buildShuttleCard({
    required int shuttleId,
    required String title,
    required String status,
    required Color statusColor,
    required Color statusBg,
    required String seats,
    required String percentage,
    required String info,
    required double progress,
    required Color progressColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: Color(0xFF1E215D),
                  ),
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: statusBg,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  status,
                  style: TextStyle(
                    color: statusColor,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              if (_isShuttleAdmin)
                IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () => _deleteShuttle(shuttleId),
                ),
            ],
          ),
          const SizedBox(height: 16),
          LinearProgressIndicator(
            value: progress,
            backgroundColor: Colors.grey.shade200,
            color: progressColor,
            minHeight: 6,
            borderRadius: BorderRadius.circular(3),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                seats,
                style: const TextStyle(color: Colors.grey, fontSize: 13),
              ),
              Text(
                percentage,
                style: const TextStyle(
                  color: Colors.grey,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            info,
            style: const TextStyle(color: Colors.grey, fontSize: 12),
          ),
        ],
      ),
    );
  }
}