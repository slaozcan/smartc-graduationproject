import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'privacy_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  final ApiService _apiService = ApiService();

  bool _isLoading = false;
  String _selectedRole = "ADMIN";

  bool _acceptDataUsage = false;
  bool _acceptLocation = false;
  bool _acceptNotifications = false;
  bool _acceptPrivacyPolicy = false;

  void _handleRegister() async {
    final name = _nameController.text.trim();
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (name.isEmpty || email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Tüm alanları doldurun.")),
      );
      return;
    }

    if (!_acceptDataUsage ||
        !_acceptLocation ||
        !_acceptNotifications ||
        !_acceptPrivacyPolicy) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Kayıt için tüm izinleri onaylamalısınız."),
        ),
      );
      return;
    }

    String role = "STUDENT";

    if (email.endsWith("@isik.edu.tr")) {
      role = "STUDENT";
    } else if (email.endsWith("@isikun.edu.tr")) {
      role = _selectedRole;
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Geçerli okul e-postası kullanmalısınız."),
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    final success = await _apiService.register(
      name,
      email,
      password,
      role,
    );

    setState(() {
      _isLoading = false;
    });

    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Kayıt başarılı.")),
      );

      if (mounted) {
        Navigator.pop(context);
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Kayıt başarısız.")),
      );
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    bool isStaffEmail =
        _emailController.text.trim().endsWith("@isikun.edu.tr");

    return Scaffold(
      backgroundColor: const Color(0xFF1E215D),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              children: [
                const Text(
                  "KAYIT OL",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 30),
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "İSİM SOYİSİM",
                        style: TextStyle(color: Colors.white70),
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _nameController,
                        style: const TextStyle(color: Colors.white),
                        decoration: _inputDecoration("Ad Soyad"),
                      ),
                      const SizedBox(height: 20),

                      const Text(
                        "EMAİL",
                        style: TextStyle(color: Colors.white70),
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _emailController,
                        onChanged: (_) => setState(() {}),
                        style: const TextStyle(color: Colors.white),
                        decoration: _inputDecoration(
                          "ogrenci@isik.edu.tr",
                        ),
                      ),

                      if (isStaffEmail) ...[
                        const SizedBox(height: 20),
                        const Text(
                          "ROL",
                          style: TextStyle(color: Colors.white70),
                        ),
                        const SizedBox(height: 8),
                        DropdownButtonFormField<String>(
                          value: _selectedRole,
                          dropdownColor: const Color(0xFF1E215D),
                          items: const [
                            DropdownMenuItem(
                              value: "ADMIN",
                              child: Text(
                                "Yönetim",
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                            DropdownMenuItem(
                              value: "SHUTTLE_ADMIN",
                              child: Text(
                                "Servis Yöneticisi",
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ],
                          onChanged: (val) {
                            setState(() {
                              _selectedRole = val!;
                            });
                          },
                          decoration: _inputDecoration("Rol seçin"),
                        ),
                      ],

                      const SizedBox(height: 20),

                      const Text(
                        "ŞİFRE",
                        style: TextStyle(color: Colors.white70),
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _passwordController,
                        obscureText: true,
                        style: const TextStyle(color: Colors.white),
                        decoration: _inputDecoration("••••••••"),
                      ),

                      const SizedBox(height: 25),

                      CheckboxListTile(
                        value: _acceptDataUsage,
                        onChanged: (val) {
                          setState(() => _acceptDataUsage = val!);
                        },
                        title: const Text(
                          "Veri kullanımını kabul ediyorum",
                          style: TextStyle(color: Colors.white),
                        ),
                        controlAffinity:
                            ListTileControlAffinity.leading,
                      ),

                      CheckboxListTile(
                        value: _acceptLocation,
                        onChanged: (val) {
                          setState(() => _acceptLocation = val!);
                        },
                        title: const Text(
                          "Konum kullanımına izin veriyorum",
                          style: TextStyle(color: Colors.white),
                        ),
                        controlAffinity:
                            ListTileControlAffinity.leading,
                      ),

                      CheckboxListTile(
                        value: _acceptNotifications,
                        onChanged: (val) {
                          setState(() => _acceptNotifications = val!);
                        },
                        title: const Text(
                          "Bildirim almayı kabul ediyorum",
                          style: TextStyle(color: Colors.white),
                        ),
                        controlAffinity:
                            ListTileControlAffinity.leading,
                      ),

                      CheckboxListTile(
                        value: _acceptPrivacyPolicy,
                        onChanged: (val) {
                          setState(() => _acceptPrivacyPolicy = val!);
                        },
                        title: GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    const PrivacyScreen(),
                              ),
                            );
                          },
                          child: const Text(
                            "Gizlilik politikasını okudum ve kabul ediyorum",
                            style: TextStyle(
                              color: Colors.white,
                              decoration:
                                  TextDecoration.underline,
                            ),
                          ),
                        ),
                        controlAffinity:
                            ListTileControlAffinity.leading,
                      ),

                      const SizedBox(height: 25),

                      SizedBox(
                        width: double.infinity,
                        height: 55,
                        child: ElevatedButton(
                          onPressed:
                              _isLoading ? null : _handleRegister,
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                                const Color(0xFF5352ED),
                            shape: RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.circular(14),
                            ),
                          ),
                          child: _isLoading
                              ? const CircularProgressIndicator(
                                  color: Colors.white,
                                )
                              : const Text(
                                  "Kayıt Ol",
                                  style: TextStyle(fontSize: 18),
                                ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  InputDecoration _inputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(
        color: Colors.white.withOpacity(0.5),
      ),
      filled: true,
      fillColor: Colors.white.withOpacity(0.1),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
      ),
    );
  }
}