import 'package:flutter/material.dart';

import '../models/facility.dart';
import '../services/api_service.dart';

class AdminFacilityManagementScreen extends StatefulWidget {
  const AdminFacilityManagementScreen({Key? key}) : super(key: key);

  @override
  State<AdminFacilityManagementScreen> createState() =>
      _AdminFacilityManagementScreenState();
}

class _AdminFacilityManagementScreenState
    extends State<AdminFacilityManagementScreen> {
  final ApiService _apiService = ApiService();

  late Future<List<Facility>> _facilitiesFuture;

  @override
  void initState() {
    super.initState();
    _loadFacilities();
  }

  void _loadFacilities() {
    setState(() {
      _facilitiesFuture = _apiService.getFacilities();
    });
  }

  Future<void> _deleteFacility(Facility facility) async {
    final success = await _apiService.deleteFacility(facility.id);

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          success ? "${facility.name} silindi." : "${facility.name} silinemedi.",
        ),
        backgroundColor: success ? Colors.green : Colors.red,
      ),
    );

    if (success) {
      _loadFacilities();
    }
  }

  void _showAddFacilityModal() {
    final nameCtrl = TextEditingController();
    final typeCtrl = TextEditingController(text: "ROOM");
    final capacityCtrl = TextEditingController();
    final latitudeCtrl = TextEditingController(text: "0.0");
    final longitudeCtrl = TextEditingController(text: "0.0");

    bool isLoading = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              padding: EdgeInsets.only(
                left: 24,
                right: 24,
                top: 24,
                bottom: MediaQuery.of(context).viewInsets.bottom + 24,
              ),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(28),
                  topRight: Radius.circular(28),
                ),
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Yeni Tesis Ekle",
                      style: TextStyle(
                        color: Color(0xFF1E215D),
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 20),
                    _buildTextField(
                      controller: nameCtrl,
                      label: "Tesis Adı",
                      hint: "Örn: Study Room A",
                    ),
                    const SizedBox(height: 12),
                    _buildTextField(
                      controller: typeCtrl,
                      label: "Tip",
                      hint: "ROOM / CLASSROOM / SPORTS",
                    ),
                    const SizedBox(height: 12),
                    _buildTextField(
                      controller: capacityCtrl,
                      label: "Kapasite",
                      hint: "Örn: 20",
                      keyboardType: TextInputType.number,
                    ),
                    const SizedBox(height: 12),
                    _buildTextField(
                      controller: latitudeCtrl,
                      label: "Latitude",
                      hint: "41.0275",
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                        signed: true,
                      ),
                    ),
                    const SizedBox(height: 12),
                    _buildTextField(
                      controller: longitudeCtrl,
                      label: "Longitude",
                      hint: "29.0412",
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                        signed: true,
                      ),
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      height: 55,
                      child: ElevatedButton(
                        onPressed: isLoading
                            ? null
                            : () async {
                                final name = nameCtrl.text.trim();
                                final type = typeCtrl.text.trim();
                                final capacity =
                                    int.tryParse(capacityCtrl.text.trim()) ?? 0;
                                final latitude =
                                    double.tryParse(latitudeCtrl.text.trim()) ??
                                        0.0;
                                final longitude =
                                    double.tryParse(longitudeCtrl.text.trim()) ??
                                        0.0;

                                if (name.isEmpty ||
                                    type.isEmpty ||
                                    capacity <= 0) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text(
                                        "Tesis adı, tip ve kapasite zorunludur.",
                                      ),
                                      backgroundColor: Colors.red,
                                    ),
                                  );
                                  return;
                                }

                                setModalState(() {
                                  isLoading = true;
                                });

                                final success =
                                    await _apiService.createFacility(
                                  name: name,
                                  type: type,
                                  capacity: capacity,
                                  latitude: latitude,
                                  longitude: longitude,
                                );

                                setModalState(() {
                                  isLoading = false;
                                });

                                if (!mounted) return;

                                Navigator.pop(context);

                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      success
                                          ? "Tesis başarıyla eklendi."
                                          : "Tesis eklenemedi.",
                                    ),
                                    backgroundColor:
                                        success ? Colors.green : Colors.red,
                                  ),
                                );

                                if (success) {
                                  _loadFacilities();
                                }
                              },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF1E215D),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        child: isLoading
                            ? const CircularProgressIndicator(
                                color: Colors.white,
                              )
                            : const Text(
                                "Tesisi Ekle",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label.toUpperCase(),
          style: const TextStyle(
            color: Colors.grey,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          keyboardType: keyboardType,
          decoration: InputDecoration(
            hintText: hint,
            filled: true,
            fillColor: Colors.grey.shade100,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide.none,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFacilityCard(Facility facility) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFF1E215D).withOpacity(0.08),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(
              Icons.business,
              color: Color(0xFF1E215D),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  facility.name,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1E215D),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "Tip: ${facility.type} • Kapasite: ${facility.capacity}",
                  style: const TextStyle(
                    color: Colors.grey,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, color: Colors.red),
            onPressed: () => _deleteFacility(facility),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F7FB),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E215D),
        foregroundColor: Colors.white,
        title: const Text("Tesisleri Yönet"),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadFacilities,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddFacilityModal,
        backgroundColor: const Color(0xFF1E215D),
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text("Yeni Tesis"),
      ),
      body: FutureBuilder<List<Facility>>(
        future: _facilitiesFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(
              child: Text("Hata: ${snapshot.error}"),
            );
          }

          final facilities = <Facility>[
            ...(snapshot.data ?? []),
          ];

          facilities.sort((a, b) => b.id.compareTo(a.id));

          if (facilities.isEmpty) {
            return const Center(
              child: Text("Henüz tesis bulunmuyor."),
            );
          }

          return RefreshIndicator(
            onRefresh: () async {
              _loadFacilities();
            },
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: facilities
                  .map<Widget>((facility) => _buildFacilityCard(facility))
                  .toList(),
            ),
          );
        },
      ),
    );
  }
}