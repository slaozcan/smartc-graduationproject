import 'dart:convert';
import 'dart:io' show Platform;

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../models/announcement.dart';
import '../models/shuttle.dart';
import '../models/facility.dart';
import '../models/reservation.dart';

class ApiService {
  static String get baseUrl {
    if (Platform.isAndroid) {
      return "http://10.0.2.2:8080";
    } else {
      return "http://10.2.113.230:8080";
    }
  }

  Future<Map<String, String>> _getHeaders() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('jwtToken');

    if (token != null && token.isNotEmpty) {
      return {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      };
    }

    return {'Content-Type': 'application/json'};
  }

  Future<Map<int, int>> getActiveReservationCountsByFacility() async {
    final url = Uri.parse('$baseUrl/reservations/counts-by-facility');

    try {
      final response = await http.get(
        url,
        headers: await _getHeaders(),
      );

      if (response.statusCode != 200) {
        print("GET COUNTS ERROR STATUS: ${response.statusCode}");
        print("GET COUNTS ERROR BODY: ${response.body}");
        return {};
      }

      final Map<String, dynamic> data = json.decode(response.body);
      final Map<int, int> counts = {};

      data.forEach((key, value) {
        final facilityId = int.tryParse(key.toString());
        final count = int.tryParse(value.toString());

        if (facilityId != null && count != null) {
          counts[facilityId] = count;
        }
      });

      print("COUNTS FROM BACKEND: $counts");
      return counts;
    } catch (e) {
      print("GET RESERVATION COUNTS ERROR: $e");
      return {};
    }
  }

  Future<Map<String, dynamic>?> getMyProfile() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('jwtToken');

    if (token == null) return null;

    final response = await http.get(
      Uri.parse('$baseUrl/auth/me'),
      headers: {
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);

      await prefs.setString('userName', data['name'] ?? '');
      await prefs.setString('userEmail', data['email'] ?? '');
      await prefs.setString('userRole', data['role'] ?? 'STUDENT');

      return data;
    }

    return null;
  }

  Future<bool> updateMyProfile(String name, String email) async {
    final response = await http.put(
      Uri.parse('$baseUrl/auth/me'),
      headers: await _getHeaders(),
      body: jsonEncode({
        'name': name,
        'email': email,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final prefs = await SharedPreferences.getInstance();

      await prefs.setString('userName', data['name'] ?? '');
      await prefs.setString('userEmail', data['email'] ?? '');
      await prefs.setString('userRole', data['role'] ?? 'STUDENT');

      return true;
    }

    return false;
  }

  Future<bool> changePassword(
    String currentPassword,
    String newPassword,
  ) async {
    final response = await http.put(
      Uri.parse('$baseUrl/auth/change-password'),
      headers: await _getHeaders(),
      body: jsonEncode({
        'currentPassword': currentPassword,
        'newPassword': newPassword,
      }),
    );

    return response.statusCode == 200;
  }

  Future<bool> login(String email, String password) async {
    final url = Uri.parse('$baseUrl/auth/login');

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'email': email.trim(),
          'password': password.trim(),
        }),
      );

      print("LOGIN STATUS: ${response.statusCode}");
      print("LOGIN BODY: ${response.body}");

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final prefs = await SharedPreferences.getInstance();

        final token = data['token'] ?? data['message'];

        if (token != null) {
          await prefs.setString('jwtToken', token);
          print("TOKEN SAVED: $token");
        } else {
          print("TOKEN NOT FOUND IN RESPONSE");
        }

        if (data['name'] != null) {
          await prefs.setString('userName', data['name']);
        }

        if (data['role'] != null) {
          await prefs.setString('userRole', data['role']);
        }

        if (data['userId'] != null) {
          await prefs.setInt('userId', data['userId']);
        }

        return true;
      }

      return false;
    } catch (e) {
      print("LOGIN ERROR: $e");
      return false;
    }
  }

  Future<bool> register(
    String name,
    String email,
    String password,
    String role,
  ) async {
    final url = Uri.parse('$baseUrl/auth/register');

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'name': name,
          'email': email,
          'password': password,
          'role': role,
        }),
      );

      return response.statusCode == 200 || response.statusCode == 201;
    } catch (e) {
      print("REGISTER ERROR: $e");
      return false;
    }
  }

  Future<List<Reservation>> getMyReservations() async {
    final url = Uri.parse('$baseUrl/reservations/me');

    try {
      final response = await http.get(
        url,
        headers: await _getHeaders(),
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        return data.map((jsonItem) => Reservation.fromJson(jsonItem)).toList();
      }

      return [];
    } catch (e) {
      print("GET MY RESERVATIONS ERROR: $e");
      return [];
    }
  }

  Future<bool> cancelReservation(int reservationId) async {
    final url = Uri.parse('$baseUrl/reservations/$reservationId');

    try {
      final response = await http.delete(
        url,
        headers: await _getHeaders(),
      );

      return response.statusCode == 200 || response.statusCode == 204;
    } catch (e) {
      print("CANCEL RESERVATION ERROR: $e");
      return false;
    }
  }

  Future<List<Facility>> getFacilities() async {
    final url = Uri.parse('$baseUrl/facilities');

    try {
      final response = await http.get(
        url,
        headers: await _getHeaders(),
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        return data.map((json) => Facility.fromJson(json)).toList();
      }

      return [];
    } catch (e) {
      print("GET FACILITIES ERROR: $e");
      return [];
    }
  }

  Future<int> getNearbyUsers(int shuttleId) async {
    final url = Uri.parse('$baseUrl/shuttles/$shuttleId/nearby-users');

    try {
      final response = await http.get(
        url,
        headers: await _getHeaders(),
      );

      if (response.statusCode == 200) {
        return int.tryParse(response.body) ?? 0;
      }

      return 0;
    } catch (e) {
      print("GET NEARBY USERS ERROR: $e");
      return 0;
    }
  }

  Future<bool> createFacility({
    required String name,
    required String type,
    required int capacity,
    required double latitude,
    required double longitude,
  }) async {
    final url = Uri.parse('$baseUrl/facilities');

    try {
      final response = await http.post(
        url,
        headers: await _getHeaders(),
        body: json.encode({
          'name': name,
          'type': type,
          'capacity': capacity,
          'latitude': latitude,
          'longitude': longitude,
        }),
      );

      return response.statusCode == 200 || response.statusCode == 201;
    } catch (e) {
      print("CREATE FACILITY ERROR: $e");
      return false;
    }
  }

  Future<bool> deleteFacility(int facilityId) async {
    final url = Uri.parse('$baseUrl/facilities/$facilityId');

    try {
      final response = await http.delete(
        url,
        headers: await _getHeaders(),
      );

      return response.statusCode == 200 || response.statusCode == 204;
    } catch (e) {
      print("DELETE FACILITY ERROR: $e");
      return false;
    }
  }

  Future<bool> createReservation(
    int facilityId,
    DateTime startTime,
    DateTime endTime, {
    double latitude = 0.0,
    double longitude = 0.0,
  }) async {
    final url = Uri.parse('$baseUrl/reservations');

    try {
      final response = await http.post(
        url,
        headers: await _getHeaders(),
        body: json.encode({
          'facilityId': facilityId,
          'startTime': startTime.toIso8601String(),
          'endTime': endTime.toIso8601String(),
          'latitude': latitude,
          'longitude': longitude,
        }),
      );

      return response.statusCode == 200 || response.statusCode == 201;
    } catch (e) {
      print("RESERVATION ERROR: $e");
      return false;
    }
  }

  Future<bool> createExamReservation(
    int facilityId,
    DateTime startTime,
    DateTime endTime,
  ) async {
    final url = Uri.parse('$baseUrl/reservations/exam');

    try {
      final response = await http.post(
        url,
        headers: await _getHeaders(),
        body: json.encode({
          'facilityId': facilityId,
          'startTime': startTime.toIso8601String(),
          'endTime': endTime.toIso8601String(),
          'latitude': 0.0,
          'longitude': 0.0,
        }),
      );

      return response.statusCode == 200 || response.statusCode == 201;
    } catch (e) {
      print("EXAM RESERVATION ERROR: $e");
      return false;
    }
  }

  Future<bool> createAnnouncement(
    String title,
    String content,
  ) async {
    final url = Uri.parse('$baseUrl/announcements');

    try {
      final response = await http.post(
        url,
        headers: await _getHeaders(),
        body: json.encode({
          'title': title,
          'content': content,
        }),
      );

      return response.statusCode == 200 || response.statusCode == 201;
    } catch (e) {
      print("ANNOUNCEMENT ERROR: $e");
      return false;
    }
  }

  Future<List<Announcement>> getAnnouncements() async {
    final url = Uri.parse('$baseUrl/announcements');

    try {
      final response = await http.get(
        url,
        headers: await _getHeaders(),
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        return data.map((json) => Announcement.fromJson(json)).toList();
      }

      return [];
    } catch (e) {
      print("GET ANNOUNCEMENTS ERROR: $e");
      return [];
    }
  }

  Future<List<Shuttle>> getShuttles() async {
    final url = Uri.parse('$baseUrl/shuttles');

    try {
      final response = await http.get(
        url,
        headers: await _getHeaders(),
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        return data.map((json) => Shuttle.fromJson(json)).toList();
      }

      return [];
    } catch (e) {
      print("GET SHUTTLES ERROR: $e");
      return [];
    }
  }

  Future<void> createShuttle(Map<String, dynamic> shuttleData) async {
    final url = Uri.parse('$baseUrl/shuttles');

    final response = await http.post(
      url,
      headers: await _getHeaders(),
      body: json.encode(shuttleData),
    );

    print("CREATE SHUTTLE STATUS: ${response.statusCode}");
    print("CREATE SHUTTLE BODY: ${response.body}");

    if (response.statusCode != 200 && response.statusCode != 201) {
      throw Exception(
        response.body.isNotEmpty
            ? response.body
            : "Shuttle eklenemedi. Status: ${response.statusCode}",
      );
    }
  }

  Future<void> deleteShuttle(int shuttleId) async {
    final url = Uri.parse('$baseUrl/shuttles/$shuttleId');

    final response = await http.delete(
      url,
      headers: await _getHeaders(),
    );

    print("DELETE SHUTTLE STATUS: ${response.statusCode}");
    print("DELETE SHUTTLE BODY: ${response.body}");

    if (response.statusCode != 200 && response.statusCode != 204) {
      throw Exception(
        response.body.isNotEmpty
            ? response.body
            : "Shuttle silinemedi. Status: ${response.statusCode}",
      );
    }
  }

  Future<String> forgotPassword(String email) async {
    final url = Uri.parse('$baseUrl/auth/forgot-password');

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'email': email,
        }),
      );

      if (response.statusCode == 200) {
        return response.body.isNotEmpty
            ? response.body
            : "Geçici şifre email adresinize gönderildi.";
      } else if (response.statusCode == 404) {
        return "Bu email adresiyle kayıtlı kullanıcı bulunamadı.";
      } else {
        return response.body.isNotEmpty
            ? response.body
            : "Şifre sıfırlama işlemi başarısız oldu.";
      }
    } catch (e) {
      return "Sunucu bağlantı hatası.";
    }
  }

  Future<String> resetPassword(
    String token,
    String newPassword,
  ) async {
    final url = Uri.parse('$baseUrl/auth/reset-password');

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'token': token,
          'newPassword': newPassword,
        }),
      );

      if (response.statusCode == 200) {
        return response.body.isNotEmpty
            ? response.body
            : "Şifreniz başarıyla güncellendi.";
      } else {
        return response.body.isNotEmpty
            ? response.body
            : "Şifre güncelleme başarısız oldu.";
      }
    } catch (e) {
      return "Sunucu bağlantı hatası.";
    }
  }

  Future<bool> updateMyLocation(double latitude, double longitude) async {
    final url = Uri.parse('$baseUrl/location/update');

    try {
      final response = await http.post(
        url,
        headers: await _getHeaders(),
        body: jsonEncode({
          'latitude': latitude,
          'longitude': longitude,
        }),
      );

      print("UPDATE LOCATION STATUS: ${response.statusCode}");
      print("UPDATE LOCATION BODY: ${response.body}");

      return response.statusCode == 200;
    } catch (e) {
      print("UPDATE LOCATION ERROR: $e");
      return false;
    }
  }
}