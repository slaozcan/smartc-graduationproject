# SMART-C Mobil Uygulaması - Mac & iPhone Kurulum Rehberi

Merhaba! Bu dosya, Sıla'nın kodladığı SMART-C mobil (Flutter) projesinin senin cihazında (Macbook) derlenip, takımın Apple cihazlarında (örn: iPhone) fiziksel bir "Native Uygulama" olarak çalıştırılabilmesi için hazırlanan bir kurulum kılavuzudur. 🚀

## Aşama 1: Mac Bilgisayarındaki Gerekli Programlar
Apple sistemleri kapalı kutu olduğu için kodu iPhone'a atabilmek adına bilgisayarında aşağıdaki programların eksiksiz yüklü olması şarttır:
1. **Flutter SDK:** (Kurulu olduğunu varsayıyoruz, yoksa resmi siteden kurulmalıdır).
2. **Xcode:** Apple'ın resmi derleyicisidir. (App Store'dan Mac'ine ücretsiz indirebilirsin).
3. **CocoaPods:** iOS kütüphanelerini bağlayan eklentidir. (Eğer Mac'inde yüklü değilse terminali açıp `sudo gem install cocoapods` yazman yeterlidir).

---

## Aşama 2: IP Adresini Girme (Çok Kritik!)
Sunum esnasında Java (Spring Boot) backend'i kimin bilgisayarından açık olacaksa, o bilgisayarın **Local IP Adresini** Flutter kodlarına yazmamız gererkiyor (aksi takdirde iPhone database'e bağlanamaz):
1. Java'nın çalıştığı bilgisayar Windows ise `ipconfig`, Mac ise terminalden `ipconfig getifaddr en0` yazılarak IP numarası alınır (Örn: `192.168.1.45`).
2. Bu projede `lib/services/api_service.dart` dosyasına girip 8. satırdaki `baseUrl` kısmını bulun:
   ```dart
   // ESKİ HALİ:
   static const String baseUrl = "http://10.0.2.2:8080";

   // SUNUM GÜNÜ ŞU ŞEKİLDE DEĞİŞTİRİLECEK (Örnek IP ile):
   static const String baseUrl = "http://192.168.1.45:8080";
   ```
*(Not: İki bilgisayarın ve test edilen iPhone'un aynı Wi-Fi/Hotspot internetine bağlı olması zorunludur).*

---

## Aşama 3: Projeyi Mac'te Ayağa Kaldırma ve İndirme
Klasörü Mac'ine taşıdıktan sonra VS Code'da veya Terminalde bu projenin ana klasörünü (`smartc_mobile`) aç ve sırasıyla şunları yaz:

```bash
flutter clean
flutter pub get
```
*Bu komutlar eski cihaz (Windows) önbelleklerini temizler ve kütüphaneleri baştan kurar.*

Şimdi iOS klasörünün içindeki Apple'a özel dosyaları işleyeceğiz:
```bash
cd ios
pod install
cd ..
```

---

## Aşama 4: Apple "Signing" (Geliştirici Güvenliği)
Apple dışarıdan kabloyla atılan kodlara kimlik doğrulaması şartı koşar.
1. Projenin içindeki `ios` klasörüne gir ve **`Runner.xcworkspace`** adlı mavi logolu belgeye çift tıklayarak **Xcode** programında aç.
2. Açılan Xcode programında, sol üst köşeden `Runner` projesine tıkla.
3. Orta üst kısımdan **"Signing & Capabilities"** sekmesine geç.
4. Oradaki **"Automatically manage signing"** (Otomatik Yönetim) etiketini işaretle.
5. **Team (Takım)** kısmından kendi kullandığın Cloud (Apple ID) hesabını seç. (Kendi AppleID hesabı şifreni bilgisayarına girerek de onaylayabilirsin).
*Bu işlem "Sıla'nın kodladığı bu uygulamanın virüs olmadığına kefilim" demektir.*

---

## Aşama 5: Büyük An (Kabloyu Tak ve Çalıştır)
Her şey hazır. 
1. Uygulamayı atacağınız fiziksel iPhone cihazını (Örn: iPhone 13) Mac'e şarj kablosuyla tak. (Telefonda "Bu cihaza güven" çıkarsa İzin Ver/Güven de).
2. Projenin ana ekranında açtığın terminalde kodu çalıştır:
```bash
flutter run
```
Biraz beklendikten sonra uygulama telefona yüklenecektir.

Telefonun ana menüsünde **SMART-C** uygulamasını göreceksin! Ancak tıkladığında ufak bir "Güvenilmeyen Geliştirici" hatası verebilir. Bu iOS tabanlı son aşamadır, çözümü kolaydır:
* iPhone cihazından **Ayarlar > Genel > VPN ve Cihaz Yönetimi** menüsüne girin.
* Kendi Apple ID mailine tıkla ve **"Güven (Trust)"** düğmesine bas.

Tebrikler. Uygulamanız iOS tarafında %100 "Native (Gerçek)" olarak hazır ve database'e bağlı. Sunumda başarılar dilerim! 🌟 
