package com.smartc.smartc.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "facilities")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Facility {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String type; // e.g. "STUDY_AREA", "GYM", "EVENT_SPACE"

    private int capacity; // Maksimum aynı anda kaç kişi rezervasyon yapabilir

    private Double latitude;

    private Double longitude;
}
