package com.smartc.smartc.controller;

import com.smartc.smartc.entity.Shuttle;
import com.smartc.smartc.service.ShuttleService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import com.smartc.smartc.service.LocationService;



@RestController
@RequestMapping("/shuttles")
@CrossOrigin(origins = "*")
public class ShuttleController {

    private final ShuttleService shuttleService;

    private final LocationService locationService;

    public ShuttleController(
        ShuttleService shuttleService,
        LocationService locationService) {
    this.shuttleService = shuttleService;
    this.locationService = locationService;
}




    // Herkes görebilir
    @GetMapping
    public List<Shuttle> getAllShuttles() {
        return shuttleService.getAllShuttles();
    }

    @GetMapping("/{id}")
    public Shuttle getShuttleById(@PathVariable Long id) {
        return shuttleService.getShuttleById(id);
    }

@GetMapping("/{id}/nearby-users")
public long getNearbyUsers(@PathVariable Long id) {
    Shuttle shuttle = shuttleService.getShuttleById(id);

    if (shuttle.getDepartureLatitude() == null ||
            shuttle.getDepartureLongitude() == null) {
        return 0;
    }

    return locationService.countUsersNear(
            shuttle.getDepartureLatitude(),
            shuttle.getDepartureLongitude(),
            0.1
    );
}










    // Sadece SHUTTLE_ADMIN yeni shuttle oluşturabilir
    @PreAuthorize("hasRole('SHUTTLE_ADMIN')")
    @PostMapping
    public Shuttle createShuttle(@RequestBody Shuttle shuttle) {
        return shuttleService.createShuttle(shuttle);
    }

    // Sadece SHUTTLE_ADMIN tüm shuttle bilgilerini güncelleyebilir
    @PreAuthorize("hasRole('SHUTTLE_ADMIN')")
    @PutMapping("/{id}")
    public Shuttle updateShuttle(@PathVariable Long id, @RequestBody Shuttle shuttle) {
        return shuttleService.updateShuttle(id, shuttle);
    }

    // Sadece SHUTTLE_ADMIN doluluk oranını değiştirebilir
    @PreAuthorize("hasRole('SHUTTLE_ADMIN')")
    @PatchMapping("/{id}/occupancy")
    public Shuttle updateOccupancy(@PathVariable Long id, @RequestParam int occupancy) {
        return shuttleService.updateOccupancy(id, occupancy);
    }

    // Sadece SHUTTLE_ADMIN statüyü değiştirebilir
    @PreAuthorize("hasRole('SHUTTLE_ADMIN')")
    @PatchMapping("/{id}/status")
    public Shuttle updateStatus(@PathVariable Long id, @RequestParam String status) {
        return shuttleService.updateStatus(id, status);
    }

    @PreAuthorize("hasRole('SHUTTLE_ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteShuttle(@PathVariable Long id) {
        shuttleService.deleteShuttle(id);
        return ResponseEntity.ok("Shuttle deleted successfully");
    }
}
