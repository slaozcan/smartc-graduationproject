package com.smartc.smartc.controller;

import com.smartc.smartc.dto.LocationRequest;
import com.smartc.smartc.service.LocationService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/location")
@CrossOrigin(origins = "*")
public class LocationController {

    private final LocationService locationService;

    public LocationController(LocationService locationService) {
        this.locationService = locationService;
    }

    @PostMapping("/update")
    public String updateLocation(
            Authentication authentication,
            @RequestBody LocationRequest request) {

        locationService.updateLocation(
                authentication.getName(),
                request.getLatitude(),
                request.getLongitude());

        return "Location updated";
    }
}
