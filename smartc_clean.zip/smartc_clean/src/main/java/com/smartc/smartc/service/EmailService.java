package com.smartc.smartc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    public void sendTemporaryPasswordEmail(String toEmail, String temporaryPassword) {

        SimpleMailMessage message = new SimpleMailMessage();

        message.setTo(toEmail);
        message.setSubject("SMART-C Temporary Password");
        message.setText(
                "Hello,\n\n" +
                "Your temporary password is:\n\n" +
                temporaryPassword +
                "\n\nPlease login using this password and change it immediately from your profile settings.\n\n" +
                "SMART-C Campus Management System"
        );

        mailSender.send(message);

        System.out.println("Email sent successfully to: " + toEmail);
    }
}