package com.smartc.smartc.service;

import com.smartc.smartc.entity.Facility;
import com.smartc.smartc.repository.FacilityRepository;
import com.smartc.smartc.repository.ReservationRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FacilityService {

    private final FacilityRepository facilityRepository;
    private final ReservationRepository reservationRepository;

    public FacilityService(FacilityRepository facilityRepository,
                           ReservationRepository reservationRepository) {
        this.facilityRepository = facilityRepository;
        this.reservationRepository = reservationRepository;
    }

    public List<Facility> getAllFacilities() {
        return facilityRepository.findAll();
    }

    public Facility getFacilityById(Long id) {
        return facilityRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Facility not found"));
    }

    public Facility createFacility(Facility facility) {
        return facilityRepository.save(facility);
    }

    public Facility updateFacility(Long id, Facility updatedFacility) {
        Facility facility = facilityRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Facility not found"));

        facility.setName(updatedFacility.getName());
        facility.setType(updatedFacility.getType());
        facility.setCapacity(updatedFacility.getCapacity());
        facility.setLatitude(updatedFacility.getLatitude());
        facility.setLongitude(updatedFacility.getLongitude());

        return facilityRepository.save(facility);
    }

    @Transactional
    public void deleteFacility(Long id) {
        if (!facilityRepository.existsById(id)) {
            throw new RuntimeException("Facility not found");
        }

        reservationRepository.deleteByFacilityId(id);

        facilityRepository.deleteById(id);
    }
}