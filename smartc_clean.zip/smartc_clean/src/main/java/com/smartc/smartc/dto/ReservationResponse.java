package com.smartc.smartc.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
public class ReservationResponse {

    private Long id;
    private Long facilityId;
    private String facilityName;
    private String facilityType;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String status;
}