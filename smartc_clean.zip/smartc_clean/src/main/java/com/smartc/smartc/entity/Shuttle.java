package com.smartc.smartc.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "shuttles")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Shuttle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    
    private String route;

    private int capacity;

    private int currentOccupancy;
    
    private String status; // e.g. "ACTIVE", "DELAYED", "CANCELLED"
 
    private Double departureLatitude;

    private Double departureLongitude;
}
