package com.smartc.smartc.controller;

import com.smartc.smartc.dto.ReservationRequest;
import com.smartc.smartc.dto.ReservationResponse;
import com.smartc.smartc.entity.Reservation;
import com.smartc.smartc.service.ReservationService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/reservations")
@CrossOrigin(origins = "*")
public class ReservationController {

    private final ReservationService reservationService;

    public ReservationController(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    @PostMapping
    public ReservationResponse createReservation(@RequestBody ReservationRequest request) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return reservationService.createReservation(auth.getName(), request);
    }

    @PostMapping("/exam")
    @PreAuthorize("hasRole('ADMIN')")
    public ReservationResponse createExamReservation(@RequestBody ReservationRequest request) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return reservationService.createExamReservation(auth.getName(), request);
    }

    @GetMapping("/me")
    public List<ReservationResponse> getMyReservations() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return reservationService.getMyReservations(auth.getName());
    }

    @GetMapping("/counts-by-facility")
    public Map<Long, Long> getActiveReservationCountsByFacility() {
        return reservationService.getActiveReservationCountsByFacility();
    }

    @PutMapping("/{id}")
    public Reservation updateReservation(
            @PathVariable Long id,
            @RequestBody Reservation reservation) {
        return reservationService.updateReservation(id, reservation);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> cancelReservation(@PathVariable Long id) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        reservationService.cancelReservation(auth.getName(), id);
        return ResponseEntity.ok("Reservation cancelled successfully");
    }

    @GetMapping("/analytics")
    public java.util.Map<String, Double> getReservationAnalytics() {
        return reservationService.getReservationAnalytics();
    }
}