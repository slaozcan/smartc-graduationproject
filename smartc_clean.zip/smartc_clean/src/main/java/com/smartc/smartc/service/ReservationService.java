package com.smartc.smartc.service;

import com.smartc.smartc.dto.ReservationRequest;
import com.smartc.smartc.dto.ReservationResponse;
import com.smartc.smartc.entity.Facility;
import com.smartc.smartc.entity.Reservation;
import com.smartc.smartc.entity.User;
import com.smartc.smartc.repository.FacilityRepository;
import com.smartc.smartc.repository.ReservationRepository;
import com.smartc.smartc.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReservationService {

    private final ReservationRepository reservationRepository;
    private final FacilityRepository facilityRepository;
    private final UserRepository userRepository;

    public ReservationService(
            ReservationRepository reservationRepository,
            FacilityRepository facilityRepository,
            UserRepository userRepository) {
        this.reservationRepository = reservationRepository;
        this.facilityRepository = facilityRepository;
        this.userRepository = userRepository;
    }

    public ReservationResponse createReservation(String email, ReservationRequest request) {
        if (request.getStartTime().isAfter(request.getEndTime())
                || request.getStartTime().isEqual(request.getEndTime())) {
            throw new RuntimeException("End time must be after start time");
        }

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Facility facility = facilityRepository.findById(request.getFacilityId())
                .orElseThrow(() -> new RuntimeException("Facility not found"));

        if (isExamFacility(facility)) {
            throw new RuntimeException("Exam classrooms can only be reserved by admin exam reservation.");
        }

        boolean userAlreadyReservedSameFacility =
                reservationRepository.findByUserUserId(user.getUserId())
                        .stream()
                        .anyMatch(reservation ->
                                reservation.getFacility() != null
                                        && reservation.getFacility().getId().equals(facility.getId())
                                        && isActiveReservation(reservation));

        if (userAlreadyReservedSameFacility) {
            throw new RuntimeException("You already have an active reservation for this facility.");
        }

        if (request.getLatitude() == null || request.getLongitude() == null) {
            throw new RuntimeException("Location data is required to make a reservation.");
        }

        if (facility.getLatitude() != null && facility.getLongitude() != null) {
            double distance = calculateHaversineDistance(
                    request.getLatitude(),
                    request.getLongitude(),
                    facility.getLatitude(),
                    facility.getLongitude());

            if (distance > 2.0) {
                throw new RuntimeException("You are too far from the facility to make a reservation.");
            }
        }

        List<Reservation> conflicts =
                reservationRepository.findByFacilityIdAndStartTimeLessThanAndEndTimeGreaterThan(
                        facility.getId(),
                        request.getEndTime(),
                        request.getStartTime());

        long activeConflictCount = conflicts.stream()
                .filter(this::isActiveReservation)
                .count();

        if (activeConflictCount >= facility.getCapacity()) {
            throw new RuntimeException("This facility is fully booked.");
        }

        Reservation reservation = new Reservation();
        reservation.setUser(user);
        reservation.setFacility(facility);
        reservation.setStartTime(request.getStartTime());
        reservation.setEndTime(request.getEndTime());
        reservation.setStatus("CONFIRMED");

        Reservation savedReservation = reservationRepository.save(reservation);

        return mapToReservationResponse(savedReservation);
    }

    public ReservationResponse createExamReservation(String email, ReservationRequest request) {
        if (request.getStartTime().isAfter(request.getEndTime())
                || request.getStartTime().isEqual(request.getEndTime())) {
            throw new RuntimeException("End time must be after start time");
        }

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Facility facility = facilityRepository.findById(request.getFacilityId())
                .orElseThrow(() -> new RuntimeException("Facility not found"));

        if (!isExamFacility(facility)) {
            throw new RuntimeException("Only exam classrooms can be reserved for exams.");
        }

        boolean userAlreadyReservedSameExamFacility =
                reservationRepository.findByUserUserId(user.getUserId())
                        .stream()
                        .anyMatch(reservation ->
                                reservation.getFacility() != null
                                        && reservation.getFacility().getId().equals(facility.getId())
                                        && isActiveReservation(reservation));

        if (userAlreadyReservedSameExamFacility) {
            throw new RuntimeException("You already have an active reservation for this exam classroom.");
        }

        if (facility.getCapacity() != 1) {
            facility.setCapacity(1);
            facilityRepository.save(facility);
        }

        List<Reservation> conflicts =
                reservationRepository.findByFacilityIdAndStartTimeLessThanAndEndTimeGreaterThan(
                        facility.getId(),
                        request.getEndTime(),
                        request.getStartTime());

        boolean hasActiveConflict = conflicts.stream()
                .anyMatch(this::isActiveReservation);

        if (hasActiveConflict) {
            throw new RuntimeException("This classroom is already reserved for the selected exam time.");
        }

        Reservation reservation = new Reservation();
        reservation.setUser(user);
        reservation.setFacility(facility);
        reservation.setStartTime(request.getStartTime());
        reservation.setEndTime(request.getEndTime());
        reservation.setStatus("EXAM_RESERVED");

        Reservation savedReservation = reservationRepository.save(reservation);

        return mapToReservationResponse(savedReservation);
    }

    public Map<Long, Long> getActiveReservationCountsByFacility() {
        List<Reservation> allReservations = reservationRepository.findAll();

        Map<Long, Long> counts = new LinkedHashMap<>();

        for (Reservation reservation : allReservations) {
            if (reservation.getFacility() == null || !isActiveReservation(reservation)) {
                continue;
            }

            Long facilityId = reservation.getFacility().getId();
            counts.put(facilityId, counts.getOrDefault(facilityId, 0L) + 1L);
        }

        return counts;
    }

    private boolean isActiveReservation(Reservation reservation) {
        return reservation.getStatus() == null
                || (!reservation.getStatus().equalsIgnoreCase("CANCELLED")
                && !reservation.getStatus().equalsIgnoreCase("REJECTED"));
    }

    private boolean isExamFacility(Facility facility) {
        String facilityType = facility.getType() == null
                ? ""
                : facility.getType().toUpperCase();

        String facilityName = facility.getName() == null
                ? ""
                : facility.getName().toUpperCase();

        return facilityType.contains("EXAM")
                || facilityType.contains("CLASSROOM")
                || facilityName.startsWith("DMF")
                || facilityName.startsWith("LMF")
                || facilityName.startsWith("DK")
                || facilityName.contains("DMF")
                || facilityName.contains("LMF");
    }

    private double calculateHaversineDistance(
            double lat1,
            double lon1,
            double lat2,
            double lon2) {

        final int R = 6371;

        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);

        double a =
                Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                        + Math.cos(Math.toRadians(lat1))
                        * Math.cos(Math.toRadians(lat2))
                        * Math.sin(lonDistance / 2)
                        * Math.sin(lonDistance / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        return R * c;
    }

    public java.util.Map<String, Double> getReservationAnalytics() {
        List<Reservation> allReservations = reservationRepository.findAll();

        if (allReservations.isEmpty()) {
            return java.util.Collections.emptyMap();
        }

        java.util.Map<java.time.DayOfWeek, Long> countsByDay =
                allReservations.stream()
                        .collect(
                                java.util.stream.Collectors.groupingBy(
                                        res -> res.getStartTime().getDayOfWeek(),
                                        java.util.stream.Collectors.counting()));

        double total = allReservations.size();

        java.util.Map<String, Double> percentages = new java.util.LinkedHashMap<>();

        for (java.time.DayOfWeek day : java.time.DayOfWeek.values()) {
            long count = countsByDay.getOrDefault(day, 0L);
            percentages.put(day.toString(), (count / total) * 100.0);
        }

        return percentages;
    }

    public List<ReservationResponse> getMyReservations(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return reservationRepository.findByUserUserId(user.getUserId())
                .stream()
                .filter(this::isActiveReservation)
                .map(this::mapToReservationResponse)
                .toList();
    }

    public void cancelReservation(String email, Long reservationId) {
        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new RuntimeException("Reservation not found"));

        if (!reservation.getUser().getEmail().equals(email)) {
            throw new RuntimeException("You can only cancel your own reservations");
        }

        reservation.setStatus("CANCELLED");
        reservationRepository.save(reservation);
    }

    private ReservationResponse mapToReservationResponse(Reservation reservation) {
        return new ReservationResponse(
                reservation.getId(),
                reservation.getFacility().getId(),
                reservation.getFacility().getName(),
                reservation.getFacility().getType(),
                reservation.getStartTime(),
                reservation.getEndTime(),
                reservation.getStatus());
    }

    public Reservation updateReservation(Long id, Reservation updatedReservation) {
        Reservation reservation = reservationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Reservation not found"));

        reservation.setStartTime(updatedReservation.getStartTime());
        reservation.setEndTime(updatedReservation.getEndTime());
        reservation.setStatus(updatedReservation.getStatus());

        if (updatedReservation.getFacility() != null) {
            reservation.setFacility(updatedReservation.getFacility());
        }

        return reservationRepository.save(reservation);
    }
}