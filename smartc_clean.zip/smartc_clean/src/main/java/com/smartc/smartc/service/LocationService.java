package com.smartc.smartc.service;

import com.smartc.smartc.entity.User;
import com.smartc.smartc.entity.UserLocation;
import com.smartc.smartc.repository.UserLocationRepository;
import com.smartc.smartc.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class LocationService {

    private final UserLocationRepository userLocationRepository;
    private final UserRepository userRepository;

    public LocationService(
            UserLocationRepository userLocationRepository,
            UserRepository userRepository) {
        this.userLocationRepository = userLocationRepository;
        this.userRepository = userRepository;
    }

    public void updateLocation(
            String email,
            Double latitude,
            Double longitude) {

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        UserLocation location = userLocationRepository
                .findByUserUserId(user.getUserId())
                .orElse(new UserLocation());

        location.setUser(user);
        location.setLatitude(latitude);
        location.setLongitude(longitude);
        location.setLastSeenAt(LocalDateTime.now());

        userLocationRepository.save(location);
    }

public long countUsersNear(
        double targetLatitude,
        double targetLongitude,
        double radiusKm) {

    LocalDateTime activeSince = LocalDateTime.now().minusMinutes(10);

    return userLocationRepository.findAll()
            .stream()
            .filter(location -> location.getLastSeenAt() != null
                    && location.getLastSeenAt().isAfter(activeSince))
            .filter(location -> location.getLatitude() != null
                    && location.getLongitude() != null)
            .filter(location -> calculateDistanceKm(
                    location.getLatitude(),
                    location.getLongitude(),
                    targetLatitude,
                    targetLongitude) <= radiusKm)
            .count();
}

private double calculateDistanceKm(
        double lat1,
        double lon1,
        double lat2,
        double lon2) {

    final int earthRadiusKm = 6371;

    double dLat = Math.toRadians(lat2 - lat1);
    double dLon = Math.toRadians(lon2 - lon1);

    double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
            + Math.cos(Math.toRadians(lat1))
            * Math.cos(Math.toRadians(lat2))
            * Math.sin(dLon / 2) * Math.sin(dLon / 2);

    double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return earthRadiusKm * c;
}




}
