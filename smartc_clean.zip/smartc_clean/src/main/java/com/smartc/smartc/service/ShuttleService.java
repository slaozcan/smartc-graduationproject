package com.smartc.smartc.service;

import com.smartc.smartc.entity.Shuttle;
import com.smartc.smartc.repository.ShuttleRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShuttleService {

    private final ShuttleRepository shuttleRepository;

    public ShuttleService(ShuttleRepository shuttleRepository) {
        this.shuttleRepository = shuttleRepository;
    }

    public List<Shuttle> getAllShuttles() {
        return shuttleRepository.findAll();
    }

    public Shuttle getShuttleById(Long id) {
        return shuttleRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Shuttle not found"));
    }

    public Shuttle createShuttle(Shuttle shuttle) {
        return shuttleRepository.save(shuttle);
    }

    public Shuttle updateOccupancy(Long id, int newOccupancy) {
        Shuttle shuttle = getShuttleById(id);
        if (newOccupancy > shuttle.getCapacity()) {
            throw new RuntimeException("Occupancy cannot exceed capacity");
        }
        shuttle.setCurrentOccupancy(newOccupancy);
        return shuttleRepository.save(shuttle);
    }

    public Shuttle updateStatus(Long id, String status) {
        Shuttle shuttle = getShuttleById(id);
        shuttle.setStatus(status);
        return shuttleRepository.save(shuttle);
    }

    public Shuttle updateShuttle(Long id, Shuttle updatedShuttle) {
        Shuttle shuttle = shuttleRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Shuttle not found"));

        shuttle.setName(updatedShuttle.getName());
        shuttle.setRoute(updatedShuttle.getRoute());
        shuttle.setCapacity(updatedShuttle.getCapacity());
        shuttle.setCurrentOccupancy(updatedShuttle.getCurrentOccupancy());
        shuttle.setStatus(updatedShuttle.getStatus());

        shuttle.setDepartureLatitude(updatedShuttle.getDepartureLatitude());
        shuttle.setDepartureLongitude(updatedShuttle.getDepartureLongitude()); 

        return shuttleRepository.save(shuttle);
    }

    public void deleteShuttle(Long id) {
        shuttleRepository.deleteById(id);
    }
}
