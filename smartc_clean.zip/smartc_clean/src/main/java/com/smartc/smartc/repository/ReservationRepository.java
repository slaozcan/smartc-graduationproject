package com.smartc.smartc.repository;

import com.smartc.smartc.entity.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation, Long> {

    List<Reservation> findByUserUserId(Long userId);

    List<Reservation> findByFacilityIdAndStartTimeBetween(
            Long facilityId,
            LocalDateTime start,
            LocalDateTime end
    );

    List<Reservation> findByFacilityIdAndStartTimeLessThanAndEndTimeGreaterThan(
            Long facilityId,
            LocalDateTime endTime,
            LocalDateTime startTime
    );

    void deleteByFacilityId(Long facilityId);
}